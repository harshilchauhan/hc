<?php
include 'navbar.php';
include 'conn.php';


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>product</title>
    <link rel="stylesheet" href="./bootstrap-5.3.0-JS and CSS/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>

</head>
<!-- <style>
    .imgdes{
        width: 1000px;
        height: 150px;
    }
</style> -->

<body>

    <div class="mt-3 mx-5">
        <h1 class="text-center ">Product Page</h1>

        <div class="container mt-3">
            <div class="row">
                <?php


                if (isset($_GET['catg'])) {
                    $cid = $_GET['catg'];
                    $sql1 = "select * from pro where cid=$cid";
                    $res1 = mysqli_query($con, $sql1);
                    $no = mysqli_num_rows($res1);
                    if ($no == 0) {
                        //echo "<h2 class='text-center text-denger'>No stock For This Catg</h2>";
                        echo "<script>alert('No Product found');window.location.href='product.php';</script>";
                        
                    }
                    while ($row1 = mysqli_fetch_assoc($res1)) {
                        $pid = $row1['pid'];
                        $ptitle = $row1['ptitle'];
                        $pdesc = $row1['pdesc'];
                        $pkey = $row1['pkey'];
                        $pimg = $row1['img'];
                        $pcid = $row1['cid'];
                        $price = $row1['price'];

                        echo "<div class='card col-md-3  mb-4 p-2 my-3'>
                        <img src='./upload/$pimg' class='card-img-top' alt='$ptitle' class='imgdes'>
                        <div class='card-body'>
                            <h5 class='card-title'>$ptitle</h5>
                            <p class='card-text'>$pdesc</p>
                            <p class='card-text'>$pkey</p>
                            <p class='card-text'>$price</p>
                            <a href='#' class='btn btn-primary'>Add To Cart</a>
                        </div>
                    </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                } else {
                    $sql = "select * from pro";
                    $res = mysqli_query($con, $sql);
                    while ($row = mysqli_fetch_assoc($res)) {
                        $pid = $row['pid'];
                        $ptitle = $row['ptitle'];
                        $pdesc = $row['pdesc'];
                        $pkey = $row['pkey'];
                        $pimg = $row['img'];
                        $pcid = $row['cid'];
                        $price = $row['price'];


                        echo " <div class='card col-md-3  mb-4 p-2 my-3'>
                        <form action='managecart.php' method='post'>
                       
                            <input type='hidden' name='hidid' value='$pid'>
                            <input type='hidden' name='hidprice' value='$price'>
                            <input type='hidden' name='hidtitle' value='$ptitle'>
                            <input type='hidden' name='hidimg' value='$pimg'>
                            <input type='hidden' name='hidqty' value='1'>
                        <img src='./upload/$pimg' class='card-img-top' alt='$ptitle' class='imgdes'>
                        <div class='card-body'>
                            <h5 class='card-title'>$ptitle</h5>
                            <p class='card-text'>$pdesc</p>
                            <p class='card-text'>$pkey</p>
                            <p class='card-text'>$price</p>
                            <a href='addtocart.php'><button type='submit' name='addtocart' class='btn btn-primary'> Add To Cart</button></a>
                            
                        </div>
                    </form>
                    </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                }


                ?>


            </div>
        </div>

    </div>

    <script src="./bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></script>
</body>

</html>